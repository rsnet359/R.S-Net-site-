RS Net - Site web prêt à déployer

Fichiers:
- index.html
- styles.css
- script.js
- assets/logo-placeholder.png

Instructions rapides:
1) Remplace les coordonnées (téléphone) dans index.html par ton numéro réel.
2) Ouvre index.html localement pour tester. Pour héberger gratuitement:
   - GitHub Pages: crée un dépôt public, pousse ces fichiers, active Pages.
   - Netlify: glisse le dossier dans Netlify Drop (site gratuit, rapide).
   - Vercel: similaire à Netlify.
3) Pour un domaine pro (rsnet.ca), achète le domaine (~15$/an) et configure les DNS
   vers GitHub Pages / Netlify / Vercel.
4) Pour formulaire professionnel, remplace le mailto par un back-end ou service like Formspree.

Besoin d'aide pour déployer? Dis-moi et je te guide pas-à-pas.
